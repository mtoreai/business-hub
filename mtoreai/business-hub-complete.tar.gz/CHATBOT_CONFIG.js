// INSTRUCTIONS: Create separate files for each chatbot
// This template shows the pattern - copy and update ASSISTANT_ID for each

const CHATBOT_CONFIGS = {
  'master-qualifier': 'asst_zVZzG3rWpxOX1hAfIBlywxkC',
  'business-credit': 'asst_mVR4rzHYGcwG3h88QHbDbzgb',
  'business-loan': 'asst_BDWRY2eXqmphfUzDKg1hUTKa',
  'business-profile': 'asst_TJaMjTZcbSY5Oam9RYCt5DeU',
  'automation-advisor': 'asst_KPeuTshkWNPVe2L9zHYCXTQx',
  'automation-stack': 'asst_DtTrQlH6CMvpNmEEeZtsmiIU',
  'marketing-advisor': 'asst_7tzsPrrLPshWo95aDlb6EL3j',
  'content-creator': 'asst_MM4sHJNrqIrmbD5cNLpIFvjM',
  'mental-clarity': 'asst_M3ClDpgUwkiEFgNtQ7WTcetM',
  'personal-credit': 'asst_9wE53wWhQzj9Bt7GFdUNJMX9'
};

// DEPLOYMENT STEPS:
// 1. Create a file for each chatbot in netlify/functions/
// 2. Name format: chat-[bot-name].js
// 3. Copy the function code from chat-master-qualifier.js
// 4. Update the ASSISTANT_ID constant
// 5. Deploy to Netlify

// Example file names:
// - chat-master-qualifier.js (already created)
// - chat-business-credit.js
// - chat-business-loan.js
// - chat-business-profile.js
// - chat-automation-advisor.js
// - chat-automation-stack.js
// - chat-marketing-advisor.js
// - chat-content-creator.js
// - chat-mental-clarity.js
// - chat-personal-credit.js
